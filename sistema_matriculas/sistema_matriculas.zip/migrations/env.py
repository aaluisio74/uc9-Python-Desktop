# NOVOS
import sys
import os

# NOVO: Garante que o Python acha o pacote sistema_matriculas
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from logging.config import fileConfig

from sqlalchemy import engine_from_config
from sqlalchemy import pool

# Importe a Base e os modelos do seu projeto
from app.database import Base # Ajuste conforme a estrutura do seu projeto
## ANTES-ANTES from app import models
## ANTES import app.models # Importante: importa os models para registrá-los na Base
from app.models import Estudante, Curso, Disciplina, Matricula, Usuario

#### TESTE Imprime no console as tabelas que o Alembic conseguiu enxergar
## print("Tabelas encontradas pelo SQLAlchemy:", Base.metadata.tables.keys())

target_metadata = Base.metadata

from alembic import context

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# add your model's MetaData object here
# for 'autogenerate' support
# from myapp import mymodel
# target_metadata = mymodel.Base.metadata
## target_metadata = None

# add your model's MetaData object here
# for 'autogenerate' support
# Certifique-se de que target_metadata aponta para Base.metadata e NÃO para None
target_metadata = Base.metadata

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata # <-- ESTE PARÂMETRO É OBRIGATÓRIO PARA O --autogenerate
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
